//
// BM Search
//

#ifndef bm_h
#define bm_h

#include <vector>
#include <string>
#include <tuple>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <unordered_map>
#include <dirent.h>

using namespace std;

int READBUFFER = 7 * 1024 * 1024;
//int READBUFFER = 40;
bool DEBUG1 = false;
bool DEBUG2 = false;
bool DEBUG3 = false;
bool DEBUG4 = false;

//bool DEBUG = true;
//bool DEBUG2 = true;
//bool DEBUG3 = true;
//bool DEBUG4 = true;

class Result {
public:
    string filepath;
    vector<int> count;
    
    Result(string _filepath) {
        filepath = _filepath;
    }
};

class Bm {
public:
    vector<string> filepaths;
    string folderPath;
    string indexFilename;
    vector<string> keywords;
    
    
    Bm(string _folderPath, string _indexFilename, vector<string> _keywords)
    {
        folderPath = _folderPath;
        indexFilename = _indexFilename;
        keywords = _keywords;
        sort(keywords.begin(), keywords.end(), compareKeyword);
        getFilenames();
    }
    
    int getFileLength(string filepath) {
        ifstream i;
        i.open(filepath, ios::in | ios::binary);
        i.seekg(0, i.end);
        int length = i.tellg();
        i.close();
        return length;
    }
    
    static bool compareFinalResult(tuple<string, float> i, tuple<string, float> j) {
        if (get<1>(i) != get<1>(j))
            return get<1>(i) > get<1>(j);
        else
            return get<0>(i) < get<0>(j);
    }
    
    static bool compareKeyword(string i, string j) {
        return i.length() > j.length();
    }
    
    vector<tuple<string, float> > getFinalResult(unordered_map<string, vector<int>> result){
        // get final result based on the avg count of keyword.
        // return a vector<tuple<string, float> >, string is the filepath, float is the avg count
        vector<tuple<string, float> > finalResult;
        int size = keywords.size();
        for (auto const &r:result) {
            int count = 0;
            for (vector<int>::const_iterator i = r.second.begin(); i != r.second.end(); i++)
                count += *i;
            float avg = (float) count / (float) size;
            finalResult.push_back(make_tuple(r.first, avg));
        }
        
        sort(finalResult.begin(), finalResult.end(), compareFinalResult);
        return finalResult;
    };
    
    
    void printResult(unordered_map<string, vector<int>> result){
        // print search final result
        vector<tuple<string, float> > finalResult=getFinalResult(result);
        
        if (DEBUG4) {
            for (auto const &r:finalResult) {
                cout << get<1>(r) << " ";
                cout << get<0>(r);
                cout << endl;
            }
        }
        
        for (auto const &r:finalResult) {
            cout << get<0>(r) << endl;
        }
        
    }
    
    int searchAll()
    {
        // search keywords for each file
        unordered_map<string, vector<int>> result;
        unordered_map<string, bool> skipFile;
        
        for (auto const &keyword: keywords) {
            for (auto const &filepath:filepaths) {
                if (!contains(skipFile, filepath)) {
                    int count = search(filepath, keyword);
                    if (count == 0) {
                        // if keyword not found, skip this file in the following search
                        skipFile[filepath] = true;
                        if (contains(result, filepath)) {
                            result.erase(filepath);
                        }
                    }
                    else {
                        if (contains(result, filepath)) {
                            result[filepath].push_back(count);
                        }
                        else {
                            vector<int> newCount;
                            newCount.push_back(count);
                            result[filepath] = newCount;
                        }
                    }
                }
            }
        }
        
        if (DEBUG3) {
            for (auto const &r:result) {
                for (vector<int>::const_iterator i = r.second.begin(); i != r.second.end(); i++)
                    cout << *i << " ";
                cout << " ";
                cout << r.first;
                cout << endl;
            }
        }
        printResult(result);
        return 0;
    }
    
    
    int search(string filepath, string keyword) {
        // BM search
        if (DEBUG2) {
            cout << "keyword: \"" << keyword << "\" file: " << filepath << endl;
        }
        filepath = folderPath + '/' + filepath;
        
        ifstream in;
        in.open(filepath, ios::in);
        
        int lastOccur[128]={-1};
        for (int i = 0; i < keyword.size(); i++){
            lastOccur[charToInt(keyword[i])]=i;
        }
        
        int buffersize;
        buffersize = READBUFFER;
        int fileLength = getFileLength(filepath);
        if (buffersize > fileLength)
            buffersize = fileLength;
        
        char *buffer = new char[buffersize];
        int leftFileLength = fileLength;
        
        int size = keyword.size();
        int maxCompare = size - 1;
        int currentCompareT = size - 1;
        int currentCompareP = size - 1;
        
        int count = 0;
        
        while (leftFileLength > 0 && in.read(buffer, min(buffersize, leftFileLength))) {
            if (DEBUG1) { cout << buffer << endl; }
            
            while (maxCompare < min(buffersize, leftFileLength)) {
                char charT = tolower(buffer[currentCompareT]);
                char charP = keyword[currentCompareP];
                if (charT == charP) {
                    // if the current char match
                    if (currentCompareP == 0) {
                        // if match all chars
                        if (DEBUG1) {
                            cout << "match!" << " at " << maxCompare - size + 1 << endl;
                            for (int i = 0; i < 30; i++)
                                cout << buffer[maxCompare + i];
                            cout << endl;
                        }
                        count++;
                        maxCompare += size;
                        currentCompareP = size - 1;
                        currentCompareT = maxCompare;
                    }
                    else {
                        currentCompareT--;
                        currentCompareP--;
                    }
                }
                else {
                    if (lastOccur[charToInt(charT)]!=-1) {
                        if (lastOccur[charToInt(charT)] < currentCompareP) {
                            // case 1
                            maxCompare = currentCompareT + (size - 1 - lastOccur[charToInt(charT)]);
                            currentCompareP = size - 1;
                            currentCompareT = maxCompare;
                        }
                        else {
                            // case 2
                            maxCompare++;
                            currentCompareP = size - 1;
                            currentCompareT = maxCompare;
                        }
                    }
                    else {
                        // case 3
                        maxCompare = currentCompareT + size;
                        currentCompareP = size - 1;
                        currentCompareT = maxCompare;
                    }
                    
                }
            }
            leftFileLength -= buffersize;
            if (leftFileLength > 0) {
                // if the maxCompare is beyond the buffer
                // then the new naxCompare should be size-1, and the read pointer should move backward
                int offset = (maxCompare - min(buffersize, leftFileLength + buffersize)) - size + 1;
                if (offset != 0) {
                    in.seekg(offset, in.cur);
                    leftFileLength -= offset;
                }
                maxCompare = size - 1;
                currentCompareT = maxCompare;
            }
            
        }
        free(buffer);
        in.close();
        if (DEBUG2) { cout << "count: " << count << endl; }
        return count;
    }
    
    
    bool contains(unordered_map<string, vector<int>> m, string c)
    {
        if (m.find(c) == m.end()) {
            return false;
        }
        return true;
    }
    
    bool contains(unordered_map<string, bool> m, string c) {
        if (m.find(c) == m.end()) {
            return false;
        }
        return true;
    }
    
    int charToInt(char i) {
        return (int) i;
    }
    
    char intToChar(int i) {
        return (char) i;
    }
    
    
    void getFilenames() {
        // find the filename inside the folderPath
        DIR *dir = NULL;
        dir = opendir(folderPath.c_str());
        struct dirent *ent;
        
        if (dir == NULL) {
            cout << "Cannot open directory";
        }
        else {
            while ((ent = readdir(dir)) != NULL) {
                if (strcmp(ent->d_name, ".") != 0 && strcmp(ent->d_name, "..") != 0) {
                    filepaths.push_back(ent->d_name);
                }
            }
            closedir(dir);
        }
    }
};


#endif //bm_h
